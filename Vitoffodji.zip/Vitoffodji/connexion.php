<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);


session_start();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>connexion</title>
    <link rel="stylesheet" href="/Vitoffodji/Style/index.css" type="text/css">
</head>

<body class="accueil">
    <div class="EnTete">
        <h1>
            SUPER PROMO RENTRÉ 2024: RÉDUCTION SUR VOS MONTRES ET CASQUE PRÉFÉRÉS<br>
            LIVRAISON OFFERTE EN FRANCE 🇫🇷 ET EU🇪🇺
        </h1>
    </div>

    <?php
    if (isset($_SESSION['erreurMotDePasse'])) {
        echo '<p class="erreur">' . $_SESSION['erreurMotDePasse'] . '</p>';
        unset($_SESSION['erreurMotDePasse']);
    }

    if (isset($_SESSION['erreurEmail'])) {
        echo '<p class="erreur">' . $_SESSION['erreurEmail'] . '</p>';
        unset($_SESSION['erreurEmail']);
    }
    ?>

    <br>
    <div id="errorMessage"></div>
    <div class="Formulaire">
        <form id="connexionForm" method="post" action="connexion.php">
            <label for="mail">Adresse mail :</label>
            <input name="mail" type="email" id="mail" required><br><br>
            <label for="mdp1">Mot de passe :</label>
            <input name="mdp1" type="password" id="mdp1" required><br>
            <p><input type="submit" value="Se connecter"></p>
            <p><input type="reset" value="Annuler"></p>
            <p>Vous n'avez pas de compte? <a href="/Vitoffodji/nouveau.php">Nouveau Client</a></p>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#connexionForm').submit(function (event) {
                event.preventDefault();

                var mail = $('#mail').val();
                var mdp1 = $('#mdp1').val();

                $.ajax({
                    type: "POST",
                    url: "connecter.php",
                    data: { mail: mail, mdp1: mdp1 },
                    dataType: 'json',
                    success: function (response) {
                        if (response.success) {
                            //alert(response.message);
                            // Rediriger vers une autre page si nécessaire
                            window.location.href = '/Vitoffodji/index.php';
                        } else {
                           $('#errorMessage').html('<p style="color: red;">' + response.message + '</p>');
                        }
                    },
                    error: function (xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });
        });
    </script>

<footer>
    <p><a href="/Vitoffodji/index.php">Retour</a></p>
</footer>

</body>
</html>
