<!DOCTYPE html>
<html lang="fr">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Nouveau Client</title>
    <link rel="stylesheet" href="/Vitoffodji/Style/index.css" type="text/css">

    <style>
        .valid {
            border: 2px solid green;
        }

        .invalid {
            border: 2px solid red;
        }

        .invalid span {
            color: red;
            font-size: 12px;
        }
    </style>
</head>

<p id="message"></p>

<body class="accueil">
    <div class="EnTete">
        <h1>
            SUPER PROMO RENTRÉ 2024: RÉDUCTION SUR VOS MONTRES ET CASQUE PRÉFÉRÉS<br>
            LIVRAISON OFFERTE EN FRANCE 🇫🇷 ET EU🇪🇺
        </h1>
    </div>

    <br>

    <div class="Formulaire">
        <form id="nouveauForm" method="post" autocomplete="off">
            <!-- Champs de saisie avec validation en temps réel -->
            <p>NOM:<input name="n" type="text" value="<?php echo isset($_POST['n']) ? htmlspecialchars($_POST['n']) : ''; ?>"><span></span></p>
            <p>Prénom:<input name="p" type="text" value="<?php echo isset($_POST['p']) ? htmlspecialchars($_POST['p']) : ''; ?>"><span></span></p>
            <p>Adresse:<input name="adr" type="text" value="<?php echo isset($_POST['adr']) ? htmlspecialchars($_POST['adr']) : ''; ?>"><span></span></p>
            <p>Numéro de téléphone:<input name="num" type="text" value="<?php echo isset($_POST['num']) ? htmlspecialchars($_POST['num']) : ''; ?>"><span></span></p>
            <p>Adresse e-mail:<input name="mail" type="email" value="<?php echo isset($_POST['mail']) ? htmlspecialchars($_POST['mail']) : ''; ?>" class="validate-email" data-initial-validation="false"><span></span></p>
            <p>Mot de passe:<input name="mdp1" type="password" value=""><span></span></p>
            <p>Confirmer votre mot de passe:<input name="mdp2" type="password"><span></span></p>
            
            <!-- Boutons de soumission et d'annulation -->
            <p><input type="submit" value="Valider" id="submitBtn"></p>
            <p><input type="reset" value="Annuler"></p>
        </form>
    </div>

    <div class="espace-vide"></div>
    <div class="espace-vide"></div>

    <footer>
        <a href="/Vitoffodji/Contact/Contact.html">Contacts</a>
    </footer>

    <!-- Inclusion de la bibliothèque jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    <script>
        $(document).ready(function () {
            console.log('Document ready');

            // Désactive le bouton de soumission par défaut
            $('#submitBtn').prop('disabled', true);

            // Fonction de validation du champ email
            function isValidEmail(email) {
                var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                return emailRegex.test(email);
            }

            // Fonction de validation du mot de passe
            function isValidPassword(password) {
                return /[A-Za-z]/.test(password) && /\d/.test(password) && /\W/.test(password);
            }

            // Fonction de mise à jour de la validation du champ
            function updateValidation(field, isValid, message) {
                if (isValid) {
                    field.removeClass('invalid').addClass('valid');
                } else {
                    field.removeClass('valid').addClass('invalid');
                    field.next('span').text(message);
                }
            }

            // Fonction pour valider le format de l'adresse e-mail
            function isValidEmailFormat(email) {
                var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                return emailRegex.test(email);
            }

            // Validation en temps réel
            $('input[name="n"], input[name="p"], input[name="adr"], input[name="num"], input[name="mail"], input[name="mdp1"], input[name="mdp2"]').on('input', function () {
                var fieldName = $(this).attr('name');
                var value = $(this).val();
                var isValid = true;
                var message = '';

                switch (fieldName) {
                    case 'n':
                        isValid = value.trim() !== '';
                        message = 'Le nom ne peut pas être vide.';
                        break;
                    case 'p':
                        isValid = value.trim() !== '';
                        message = 'Le prénom ne peut pas être vide.';
                        break;
                    case 'adr':
                        isValid = value.trim() !== '';
                        message = 'L\'adresse ne peut pas être vide.';
                        break;
                    case 'num':
                        isValid = value.trim() !== '';
                        message = 'Le numéro de téléphone ne peut pas être vide.';
                        break;
                    case 'mail':
                        var emailInput = $(this);
                        var vemail = emailInput.val().trim();
                        isValid = isValidEmailFormat(value);

                        // Effectuer une requête AJAX pour vérifier l'existence de l'e-mail
                        $.ajax({
                            type: 'POST',
                            url: 'verifier_email.php',
                            data: { mail: value },
                            dataType: 'json', // Indiquez que vous attendez du JSON en réponse
                            success: function (response) {
                                console.log('Réponse du serveur:', response);
                                if (!response.emailExists) {
                                    updateValidation($('input[name="mail"]'), isValid, '');
                                } else {
                                    updateValidation($('input[name="mail"]'), false, 'Adresse e-mail déjà existante.');
                                }
                                updateSubmitButtonState();
                            },
                            error: function (xhr, status, error) {
                                console.error('Erreur lors de la vérification de l\'adresse e-mail:', error);
                                // Gérer l'erreur de manière appropriée, par exemple, en traitant l'adresse e-mail comme valide
                                updateValidation($('input[name="mail"]'), isValid, 'Erreur lors de la vérification de l\'adresse e-mail.');
                                updateSubmitButtonState();
                            }
                        });

                        break;

                    case 'mdp1':
                        isValid = isValidPassword(value);
                        message = 'Le mot de passe doit contenir au moins une lettre, un chiffre et un caractère spécial.';
                        break;
                    case 'mdp2':
                        var mdp1 = $('input[name="mdp1"]').val();
                        isValid = value === mdp1;
                        message = 'Les mots de passe ne correspondent pas.';
                        break;
                    default:
                        break;
                }

                // Met à jour la validation pour le champ spécifique
                updateValidation($('input[name="' + fieldName + '"]'), isValid, message);
                updateSubmitButtonState();

                // Efface le message d'erreur si le champ est valide
                if (isValid) {
                    $('input[name="' + fieldName + '"]').next('span').text('');
                }
            });

            // Fonction pour mettre à jour l'état du bouton de soumission
            function updateSubmitButtonState() {
                var isFormValid = $('input.invalid').length === 0;
                $('#submitBtn').prop('disabled', !isFormValid);
            }

            // Validation lors de la soumission du formulaire
            $('#nouveauForm').submit(function (event) {
                // Empêcher le comportement par défaut du formulaire
                event.preventDefault();

                // Créer un objet FormData à partir du formulaire
               var formData = new FormData(this);

                // Effectuer la requête AJAX
                $.ajax({
                    type: "POST",
                    url: "enregistrement.php",
                    data: formData,
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function (response) {
                        // Traiter la réponse JSON
                        if (response.success) {
                            console.log('Réponse du serveur:', response);
                            // Afficher un message de succès
                            $("#message").html('<p style="color: green;">' + response.message + '</p>');

                            // Rediriger vers l'accueil après 1 seconde
                            setTimeout(function () {
                                window.location.href = '/Vitoffodji/index.php';
                            }, 3000);
                        } else {
                            // Afficher un message d'erreur
                            $("#message").html('<p style="color: red;">' + response.message + '</p>');
                        }
                    },
                    error: function (xhr, status, error) {
                        console.error('Erreur AJAX:', xhr.responseText);
                    }
                });
            });
        });
    </script>
<footer>
    <p><a href="/Vitoffodji/index.php">Retour</a></p>
</footer>

</body>
</html>
