<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

function getBd() {
    $bdd = new PDO('mysql:host=localhost;dbname=AdjimonVitofStore;charset=utf8', 'root', 'root');
    return $bdd;
}

// Fonction pour enregistrer un nouveau client dans la base de données
function enregistrer($nom, $prenom, $adresse, $numero, $mail, $mdp1) {
    // Obtenir une connexion à la base de données en utilisant la fonction getBD()
    $bdd = getBd();

    $hashmdp = password_hash($mdp1, PASSWORD_BCRYPT);

    // Préparer la requête SQL d'insertion dans la table "Clients"
    $sql = "INSERT INTO Clients (nom, prenom, adresse, numero, mail, mdp) VALUES (:nom, :prenom, :adresse, :numero, :mail, :mdp)";

    // Exécuter la requête en liant les valeurs des paramètres
    $requete = $bdd->prepare($sql);
    $requete->bindParam(":nom", $nom);
    $requete->bindParam(":prenom", $prenom);
    $requete->bindParam(":adresse", $adresse);
    $requete->bindParam(":numero", $numero);
    $requete->bindParam(":mail", $mail);
    $requete->bindParam(":mdp", $hashmdp);

    try {
        // Tenter d'exécuter la requête
        $result = $requete->execute();

        if (!$result) {
            $response["success"] = false;
            $response["message"] = "Échec de l'enregistrement. Erreur SQL : " . implode(" ", $requete->errorInfo());
        } else {
            $response["success"] = true;
            $response["message"] = "Le compte a été créé avec succès.";
        }
    } catch (PDOException $e) {
        // En cas d'erreur, afficher un message d'erreur
        $response["success"] = false;
        $response["message"] = 'Erreur d\'exécution de la requête : ' . $e->getMessage();
    }

    // Fermer la connexion à la base de données
    $bdd = null;
    return $response;
}

// Vérifier si les données sont soumises via le formulaire POST
if ($_SERVER["REQUEST_METHOD"] == "POST" ) {
    // Récupérer les données du formulaire
    $nom = $_POST["n"];
    $prenom = $_POST["p"];
    $adresse = $_POST["adr"];
    $numero = $_POST["num"];
    $mail = $_POST["mail"];
    $mdp1 = $_POST["mdp1"];
    $mdp2 = $_POST["mdp2"];

    // Initialiser le tableau de réponse
    $response = array();

    if (empty($nom) || empty($prenom) || empty($adresse) || empty($numero) || empty($mail) || $mdp1 !== $mdp2) {
        $response["success"] = false;
        $response["message"] = "Erreur de validation du formulaire. Veuillez remplir tous les champs correctement.";
    } else {
        // Appeler la fonction "enregistrer" avec les données du client
        $result = enregistrer($nom, $prenom, $adresse, $numero, $mail, $mdp1);

        if (!$result["success"]) {
            $response["success"] = false;
            $response["message"] = "Erreur lors de la création du compte.";
            $response["sql_errors"] = $result["message"];
        } else {
            $response["success"] = true;
            $response["message"] = "Le compte a été créé avec succès.";
            
        }
    }

    // Retourner la réponse au format JSON
    header('Content-Type: application/json');
    echo json_encode($response);
} else {
    #echo '<meta http-equiv="refresh" content="0;url =/Vitoffodji/index.php">';
    exit;
}
?>
