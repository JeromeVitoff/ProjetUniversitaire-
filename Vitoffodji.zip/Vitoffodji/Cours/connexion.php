<!DOCTYPE html>
 <html lang="fr">
   <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <title>connexion</title>
      
   </head>
   <body>  
     <?php
              session_start();
              $_SESSION['nom'] = 'Sallaberry';
              $_SESSION['prenom'] = 'Arnaud';
        ?>
    </body>
</html>     