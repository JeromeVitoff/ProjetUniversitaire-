<!DOCTYPE html>
 <html lang="fr">
   <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <title>bonjour</title>
      
   </head>
   <body>  
   <?php
              session_start();
         ?>
         <!-- Votre code HTML /PHP -->
         <?php
              echo "Bonjour M. ";
              echo $_SESSION['prenom'];
              echo " ";
              echo $_SESSION['nom'];
         ?>
         <!-- Votre code HTML /PHP -->
    </body>
</html> 