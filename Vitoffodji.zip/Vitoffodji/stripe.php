<?php
require_once('/Applications/MAMP/htdocs/Vitoffodji/vendor/autoload.php');

$cle = 'sk_test_51OFwwZELB90luxXq5T7lXQm3Q6ubaPpmXwu5qDZqZ0UpCVef1CVrSrnHBMTFPQPfB4zsWBfwEqfBIqlwHqOYh6eD00HAekIHTw';

$stripe = new \Stripe\StripeClient($cle);
?>
