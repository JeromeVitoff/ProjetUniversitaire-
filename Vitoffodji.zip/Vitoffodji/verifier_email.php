<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

function getBd()
{
    try {
        $bdd = new PDO('mysql:host=localhost;dbname=AdjimonVitofStore;charset=utf8', 'root', 'root');
        $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Définir le mode d'erreur sur exception
        return $bdd;
    } catch (PDOException $e) {
        die(json_encode(array('error' => 'La connexion à la base de données a échoué : ' . $e->getMessage())));
    }
}

// Obtenir une connexion à la base de données en utilisant la fonction getBD()
$bdd = getBd();

// Récupérer l'adresse e-mail à vérifier depuis la requête GET
$emailAVerifier = isset($_POST['mail']) ? $_POST['mail'] : '';
// Message de débogage
//var_dump($emailAVerifier);

// Préparer la requête SQL pour vérifier si l'adresse e-mail existe
$requete = "SELECT COUNT(*) as count FROM Clients WHERE mail = :mail";

try {
    $requetePreparee = $bdd->prepare($requete);

    // Lier les paramètres
    $requetePreparee->bindParam(":mail", $emailAVerifier);

    // Exécuter la requête
    $requetePreparee->execute();

    // Vérifier les erreurs
    $erreurInfo = $requetePreparee->errorInfo();
    //var_dump($erreurInfo);

    // Lire le résultat de la requête
    $resultat = $requetePreparee->fetch(PDO::FETCH_ASSOC);

    // Vérifier si l'adresse e-mail existe dans la base de données
    $emailExiste = ($resultat['count'] > 0);
    //var_dump($emailExiste);


    // Retourner la réponse au format JSON
    header('Content-Type: application/json');
    echo json_encode(array('emailExists' => $emailExiste));

    // Fermer la connexion à la base de données
    $requetePreparee->closeCursor();
    $bdd = null;
} catch (PDOException $e) {
    die(json_encode(array('error' => 'Erreur lors de l\'exécution de la requête SQL : ' . $e->getMessage())));
}
?>
