const totalRows = 10; // Le nombre total de lignes de tuiles
const totalColumns = 21; // Le nombre total de colonnes de tuiles
const totalTiles = totalRows * totalColumns; // Le nombre total de tuiles
let currentTile = 1; // La tuile actuelle à charger
const imageContainer = document.getElementById('imageContainer');

function loadNextTile() {
    if (currentTile <= totalTiles) {
        loadImageTile(currentTile);
        currentTile++;
    } else {
        alert("Vous avez reconstitué l'image !");
    }
}

function loadImageTile(tileNumber) {
    const imageUrl = `/Users/jerome/Documents/L3-MIASHS/Semestre5/Programmation web/TP_P/TP_M/TD11/img_${tileNumber}.png`;

    const image = document.createElement('img');
    image.src = imageUrl;
    image.alt = `Tuile ${tileNumber}`;
    image.classList.add('imageTile');

    imageContainer.appendChild(image);
}

// Charger la première tuile au chargement de la page
loadNextTile();
