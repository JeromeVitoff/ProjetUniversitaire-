<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

function getBd(){
    $bdd = new PDO('mysql:host=localhost;dbname=AdjimonVitofStore;charset=utf8', 'root', 'root');
    return $bdd;
} 

$response = array();

// Vérifier si le formulaire a été soumis par la méthode post
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les données du formulaire
    $mail = $_POST["mail"];
    $mdp1 = $_POST["mdp1"];

    // Vérifier si les informations sont vides
    if (empty($mail) || empty($mdp1)) {
        $response = array(
            'success' => false,
            'message' => 'Adresse e-mail ou mot de passe incorrect.'
        );
    } else {    
        // Se connecter à la base de données
        $bdd = getBd();
        $hashmdp = password_hash($mdp1, PASSWORD_BCRYPT);
        
        // Préparer la requête pour récupérer les informations du client
        $sql = "SELECT * FROM Clients WHERE mail = :mail";

        $requete = $bdd->prepare($sql);
        // Exécuter la requête en liant les paramètres
        $requete->bindParam(":mail", $mail);
        $requete->execute(); 
         
        // Récupérer les résultats de la requête; 
        $client = $requete->fetch(PDO::FETCH_ASSOC);
        
        // Vérifier si un client correspondant a été trouvé
        if ($client) {
            // Vérifier le mot de passe avec password_verify
            if (password_verify($mdp1, $client['mdp'])) {
                // Authentification réussie, créer une variable de session pour stocker les informations du client
                $_SESSION['client'] = $client;
                $response = array(
                    'success' => true,
                    'message' => 'Connexion réussie.'
                );
            } else { 
                $response = array(
                    'success' => false,
                    'message' => 'Mot de passe incorrect.'
                );
            } 
        } else {
            $response = array(
                'success' => false,
                'message' => 'Adresse e-mail ou Mot de passe incorrecte.'
            );
        }
        $bdd = null;
    }
} else {
    // La demande n'est pas une requête POST, gérer cette situation
    $response = array(
        'success' => false,
        'message' => 'Requête non valide.'
    );
}

echo json_encode($response);
exit;
?>
