<?php
session_start();
?>     



<!DOCTYPE html>
<html lang="fr">
   <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <title>index</title>
      <link rel="stylesheet" href="/Vitoffodji/Style/index.css" type="text/css">
   </head>
   
   <body class="accueil">
    
      <div class="EnTete">
       <h1>
               SUPER PROMO RENTRÉ 2024: RÉDUCTION SUR VOS MONTRES ET CASQUE PRÉFÉRÉS<br>
               LIVRAISON OFFERTE EN FRANCE 🇫🇷 ET EU🇪🇺  
               
        </h1>
      </div>  
      <div class="Menu">
        <img src="/Vitoffodji/Images/Logo.png" alt="" id="Image0">



        <?php
      // Vérifiez si une session est active (l'utilisateur est connecté)
        if (isset($_SESSION['client'])) {
         // Affichez le message de bienvenue
         echo '<p><strong> Bonjour ' . $_SESSION['client']['prenom'] . ' ' . $_SESSION['client']['nom'] . '</strong></p>';  
         // Affichez le lien de déconnexion
         echo '<p><a href="/Vitoffodji/Articles/panier.php">Voir le panier</a></p>';
         echo '<a href="/Vitoffodji/Articles/historique.php">Historique des commandes</a>';
         echo '<p><a href="deconnexion.php">Se déconnecter</a></p>';
      } else {
         // L'utilisateur n'est pas connecté, affichez les liens "Nouveau Client" et "Se connecter"
         echo '<p><a href="nouveau.php">Nouveau Client</a></p>';
         echo '<p><a href="connexion.php">Se connecter</a></p>';
      }

      ?>  
       <br> 
        <h2>Articles en Stock</h2>
        <?php 
            include("bd.php"); // Import du fichier bd.php
           // Appel de la fonction de connexion à la base de données
          $bdd = getBD();

          echo"<table>";
          echo '<tr>
            <th>id_art</th>
            <th>nom</th>
            <th>quantite</th>
            <th>prix</th>
            <th>url_photo</th>
            <th>description</th>
            </tr>';

           // Requête SQL pour récupérer les données des articles
           $rep = $bdd->query("SELECT * FROM Articles");
            
          
          
              while ($ligne = $rep->fetch()) {
                  echo "<tr>";
                  echo "<td>".$ligne["id_art"]."</td>";
                  echo '<td><a href="/Vitoffodji/Articles/articles.php?id_art=' .$ligne['id_art']. '">'.$ligne['nom'].'</a></td>';
                  echo "<td>".$ligne["quantite"]."</td>";
                  echo "<td>".$ligne["prix"]."</td>";
                  echo '<td><img src="' . $ligne['url_photo'].'" alt="'.$ligne['nom']. '" height = "100"></td>';
                  echo "<td>".$ligne['description']."€</td>"; 
                  echo "</tr>";
              }
              echo"</table>";
          
            // Fermeture de la connexion
           $rep->closeCursor();
        ?>
           

           
      <div class="espace-vide"></div>
      <div class="espace-vide"></div>

      <footer>
        <a href="/Vitoffodji/Contact/Contact.html">Contacts</a>  
      </footer>

   </body>
</html>
