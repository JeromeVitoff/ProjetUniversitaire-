<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once('/Applications/MAMP/htdocs/Vitoffodji/vendor/autoload.php');
require_once('/Applications/MAMP/htdocs/Vitoffodji/stripe.php');

if ($_SERVER['REQUEST_METHOD'] !=='POST') {
    echo 'Invalid request';
    exit;
}



session_start();

if (!isset($_SESSION['client'])) {
    header("Location: index.php");
    exit;
}

// Connectez-vous à la base de données
function getBd() {
    $bdd = new PDO('mysql:host=localhost;dbname=AdjimonVitofStore;charset=utf8', 'root', 'root');
    return $bdd;
}

$bdd = getBd();

if (isset($_POST['prix'])){
    $prix_total = $_POST['prix'];

    if(isset($_SESSION['client'])) {
         
        $client = $_SESSION['client'];
        $panier = isset($_SESSION['panier']) ?  $_SESSION['panier'] : array();
        //var_dump($panier);
        // Assurez-vous que $_SESSION['client']['ID_STRIPE'] est défini et non vide
        if (isset($_SESSION['client']['ID_STRIPE']) && !empty($_SESSION['client']['ID_STRIPE'])) {
        
            $Element = [];
            
            // Boucle à travers le panier
            foreach ($panier as $article) {
                //var_dump($article);
                $artid = isset($article['id_article']) ? $article['id_article'] : '';
                $quantite = isset($article['quantité']) ? intval($article['quantité']) : 1;
                var_dump($quantite);
                var_dump($artid);
                // Ajoutez cette vérification pour vous aider à identifier les valeurs de quantity invalides
                if (!is_numeric($quantite)) {
                // Affichez la valeur de quantity pour identifier le problème
                //var_dump($quantite);
                 }  
                
                $reqsql = "SELECT nom, prix, ID_STRIPE_PRODUIT FROM Articles WHERE  id_art = :id_art";
                $requetes = $bdd->prepare($reqsql);
                $requetes->bindparam(":id_art", $artid, PDO::PARAM_INT);
                $requetes->execute();
                $resultats = $requetes->fetch(PDO::FETCH_ASSOC);
                //var_dump($resultats);
                
        
                if ($resultats) {
                    $id_str = $resultats["ID_STRIPE_PRODUIT"];
        
                    $Element[] = [
                        'price' => $id_str,
                        'quantity' => $quantite,
                    ];
                } else {
                    echo 'Erreur lors de la recupération des info de l\article';
                    exit;
                }
                var_dump($quantite);
            }
            
        
            // Créer la session de paiement avec Stripe
            $checkout_session = $stripe->checkout->sessions->create([
                //'customer' =>'sk_test_51OFwwZELB90luxXq5T7lXQm3Q6ubaPpmXwu5qDZqZ0UpCVef1CVrSrnHBMTFPQPfB4zsWBfwEqfBIqlwHqOYh6eD00HAekIHTw'
                'success_url' => 'http://localhost:8888/Vitoffodji/Articles/acheter.php',
                'cancel_url' => 'http://localhost:8888/Vitoffodji/index.php',
                'mode' => 'payment',
                'automatic_tax' => ['enabled' => false],
                'line_items' => $Element,
            ]);
        
            // Rediriger vers l'URL de la session de paiement
            header('Location: ' . $checkout_session->url);
            exit;
        } else {
            // Gérez le cas où $_SESSION['client']['ID_STRIPE'] n'est pas défini ou est une chaîne vide
            echo 'Erreur : ID du client invalide.';
            exit;
        }    
    }

} 
?>

