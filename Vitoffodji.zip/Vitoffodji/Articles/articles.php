<!DOCTYPE html>
<html lang="fr">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>index</title>
    <link rel="stylesheet" href="/Vitoffodji/Style/index.css" type="text/css">
</head>

<body class="articles">

    <div class="EnTete">
        <h1>
            SUPER PROMO RENTRÉ 2024: RÉDUCTION SUR VOS MONTRES ET CASQUE PRÉFÉRÉS<br>
            LIVRAISON OFFERTE EN FRANCE 🇫🇷 ET EU🇪🇺

        </h1>
    </div>
    <div class="Menu">
        <img src="/Vitoffodji/Images/Logo.png" alt="" id="Image0">
    </div>
    <br>
    <h2>Articles en Stock</h2>
</body>
</html>

<?php


function getBd(){
    $bdd = new PDO('mysql:host=localhost;dbname=AdjimonVitofStore;charset=utf8', 'root', 'root');
    return $bdd;
}

$bdd = getBd();
$id_art = $_GET["id_art"];
$rep = $bdd->query("SELECT * FROM Articles WHERE id_art = $id_art");
$art = $rep->fetch(PDO::FETCH_ASSOC);
echo "<h1>".$art['nom']."</h1>";
echo '<img src="' .$art['url_photo'].'" alt="photo" height="100">';
echo "<p'><strong> Produit restants : " .$art['quantite']. "</strong></p>";
echo "<p><strong> prix : " .$art['prix']." euros </strong></p>";
echo "<p><strong> Descriptions des articles: </strong></p>";
echo "<ul class='listeD'>";
echo "<ol>" .$art['description']. "</ol>";

$rep->closeCursor();

session_start();


if (isset($_SESSION['client'])) {

    // Récupérez l'identifiant de l'article (à partir de votre code existant)

    $id_article = $id_art;

    // Affichez le formulaire pour ajouter au panier
    ?>
    <form action="ajouter.php" method="post">
        <input type="hidden" name="id_article" value="<?php echo $id_article; ?>">
        <label for="quantite">Quantité :</label>
        <input type="number" name="quantite" id="quantite" min="1" max="<?php echo $art['quantite']; ?>" value="1" required>
        <input type="submit" value="Ajoutez à votre panier">
</form>
    </form>
    <?php

    if (isset($_POST['quantite'])) {
        // Vérifiez si la quantité demandée est valide
        $quantite_demandee = intval($_POST['quantite']);

        // Récupérez la quantité en stock depuis la base de données
        $stmt = $bdd->prepare("SELECT quantite FROM Articles WHERE id_art = :id_art");
        $stmt->bindParam(':id_art', $id_article);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

       
            // La quantité demandée est valide, ajoutez l'article au panier
            if (isset($_SESSION['panier'][$id_article])) {
                // L'article est déjà dans le panier, mettez à jour la quantité
                $_SESSION['panier'][$id_article]['quantite'] += $quantite_demandee;
            } else {
                // L'article n'est pas encore dans le panier, ajoutez-le
                $_SESSION['panier'][$id_article] = [
                    'id_article' => $id_article,
                    'quantite' => $quantite_demandee
                ];
            }

            // Redirigez l'utilisateur vers la page du panier ou d'où il vient
            header("Location: ../index.php");
            exit;
        
    }
} else {
    // Afficher un message si l'utilisateur n'est pas connecté
    echo 'Veuillez vous connecter pour ajouter cet article à votre panier.';
}

echo "<a href='/Vitoffodji/index.php'> Retour</a>";
?>
