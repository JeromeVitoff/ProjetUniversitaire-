<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

function login($nom, $password) {

    // Récupération de l'ID Stripe de l'utilisateur
    $id_stripe = getIdStripeFromDatabase($nom);

}

function getIdStripeFromDatabase($nom) {
    // Remplacez ces lignes avec votre logique d'accès à la base de données
    $bdd = getBd();
    $stmt = $bdd->prepare("SELECT ID_STRIPE FROM Clients WHERE nom = :nom");
    $stmt->bindParam(':nom', $nom);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    return $result['ID_STRIPE'];
}
?>
