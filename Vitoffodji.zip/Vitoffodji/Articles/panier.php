<?php
session_start();

// Inclure votre fichier de connexion à la base de données (bd.php)
include("bd.php");

// Vérifiez si l'utilisateur est connecté
if (!isset($_SESSION['client'])) {
    // L'utilisateur n'est pas connecté, redirigez-le ou affichez un message d'erreur
    header("Location: index.php");
    exit;
}

// Initialiser un tableau pour le panier s'il n'existe pas encore
if (!isset($_SESSION['panier'])) {
    $_SESSION['panier'] = array();
}

// Fonction pour calculer le prix total d'un article en fonction de la quantité
function calculerPrixTotal($prix, $quantite) {
    return $prix * $quantite;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <title>index</title>
      <link rel="stylesheet" href="/Vitoffodji/Style/index.css" type="text/css">
</head>
<body class="accueil">
      <div class="EnTete">
       <h1>
               SUPER PROMO RENTRÉ 2024: RÉDUCTION SUR VOS MONTRES ET CASQUE PRÉFÉRÉS<br>
               LIVRAISON OFFERTE EN FRANCE 🇫🇷 ET EU🇪🇺                
        </h1>
      </div>
    
      <h2>Votre Panier</h2>


    <?php
    // Connectez-vous à la base de données
    function getBd(){
        $bdd = new PDO('mysql:host=localhost;dbname=AdjimonVitofStore;charset=utf8', 'root', 'root');
        return $bdd;
    }
    $bdd = getBD();

    // Afficher le contenu du panier s'il n'est pas vide
    if (!empty($_SESSION['panier'])) {
        echo '<table>
            <tr>
                <th>Id Article</th>
                <th>Nom</th>
                <th>Prix unitaire</th>
                <th>Quantité</th>
                <th>Prix Total</th>
            </tr>';

        $totalPrixCommande = 0;

        foreach ($_SESSION['panier'] as $article) {
            $id_art = $article['id_article'];
            $quantite = $article['quantite'];

            // Récupérer les informations de l'article depuis la base de données
            $stmt = $bdd->prepare("SELECT * FROM Articles WHERE id_art = :id_art");
            $stmt->bindParam(':id_art', $id_art);
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            // Afficher les détails de l'article dans le tableau
            echo '<tr>';
            echo '<td>' . $id_art . '</td>';
            echo '<td>' . $result['nom'] . '</td>';
            echo '<td>' . $result['prix'] . ' €</td>';
            echo '<td>' . $quantite . '</td>';
            $prixTotal = calculerPrixTotal($result['prix'], $quantite);
            echo '<td>' . $prixTotal . ' €</td>';
            echo '</tr>';

            // Mettez à jour le prix total de la commande
            $totalPrixCommande += $prixTotal;
        }

        echo '</table>';
        echo '<p>Montant de la commande : ' . $totalPrixCommande . ' €</p>';
          if (!empty($_SESSION['panier'])) {
            ?>
            <form action="commande.php" method="post">
                <input type="hidden" name="prix" value="<?php echo $prixTotal; ?>">
                <input type="submit" value ="Valider la commande">
            </form>
            <?php
          } 
    } else {
        echo 'Votre panier ne contient aucun article.';
    }
    


    // Lien de retour vers index.php
    echo '<p><a href="../index.php">Retour</a></p>';
    ?>
</body>
</html>
