<!DOCTYPE html>
<html lang="fr">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Commande enregistrée</title>
    <link rel="stylesheet" href="/Vitoffodji/Style/index.css" type="text/css">
</head>
<body class="accueil">
      <div class="EnTete">
       <h1>
               SUPER PROMO RENTRÉ 2024: RÉDUCTION SUR VOS MONTRES ET CASQUE PRÉFÉRÉS<br>
               LIVRAISON OFFERTE EN FRANCE 🇫🇷 ET EU🇪🇺
        </h1>
      </div>
      <h2>Commande bien enregistrée</h2>
</body>
</html>

<?php
session_start();

// Inclure votre fichier de connexion à la base de données (bd.php)
//include("bd.php");
// Connectez-vous à la base de données
function getBd() {
    $bdd = new PDO('mysql:host=localhost;dbname=AdjimonVitofStore;charset=utf8', 'root', 'root');
    return $bdd;
}

if (!isset($_SESSION['client']) || empty($_SESSION['panier'])) {
    // L'utilisateur n'est pas connecté ou le panier est vide
    header("Location: index.php");
    exit;
}


    // Connectez-vous à la base de données
    $bdd = new PDO('mysql:host=localhost;dbname=AdjimonVitofStore;charset=utf8', 'root', 'root');

    // Début de la transaction pour garantir la cohérence des données
    $bdd->beginTransaction();

    foreach ($_SESSION['panier'] as $article) {
        $id_article = $article['id_article'];
        $quantite = $article['quantite'];

        // Insérez chaque article dans la table Commandes
        $stmt = $bdd->prepare("INSERT INTO Commandes (id_art, id_client, quantite) VALUES (:id_art, :id_client, :quantite)");
        $stmt->bindParam(':id_art', $id_article);
        $stmt->bindParam(':id_client', $_SESSION['client']['id_client']);
        $stmt->bindParam(':quantite', $quantite);
        $stmt->execute();
    }

    // Mettez à jour la quantité des articles en stock (table Articles)
    foreach ($_SESSION['panier'] as $article) {
        $id_article = $article['id_article'];
        $quantite = $article['quantite'];

        // Réduisez la quantité en stock de l'article dans la table Articles
        $stmt = $bdd->prepare("UPDATE Articles SET quantite = quantite - :quantite WHERE id_art = :id_art");
        $stmt->bindParam(':quantite', $quantite);
        $stmt->bindParam(':id_art', $id_article);
        $stmt->execute();
    }

    // Validez la transaction
    $bdd->commit();

    // Videz le panier du client
    unset($_SESSION['panier']);

    // Affichez un message de succès
    echo 'Votre commande a bien été enregistrée. <a href="../index.php">Retour</a>';

    // En cas d'erreur, annulez la transaction et affichez un message d'erreur
    $bdd->rollBack();
    echo 'Une erreur s\'est produite lors de l\'enregistrement de la commande.';


?>

