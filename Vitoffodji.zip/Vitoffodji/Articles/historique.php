<?php
session_start();

// Vérifiez si l'utilisateur est connecté
if (!isset($_SESSION['client'])) {
    header("Location: index.php");
    exit;
}

// Inclure votre fichier de connexion à la base de données (bd.php)
//include("bd.php");
function getBd() {
    $bdd = new PDO('mysql:host=localhost;dbname=AdjimonVitofStore;charset=utf8', 'root', 'root');
    return $bdd;
}

// Connectez-vous à la base de données
$bdd = getBd();

// Obtenez l'historique des commandes de l'utilisateur
$id_client = $_SESSION['client']['id_client'];
$stmt = $bdd->prepare("SELECT c.id_commande, c.id_art, a.nom, a.prix, c.quantite, c.envoi FROM Commandes c INNER JOIN Articles a ON c.id_art = a.id_art WHERE c.id_client = :id_client");
$stmt->bindParam(':id_client', $id_client);
$stmt->execute();
$historique = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Affichez l'historique des commandes sous forme de tableau
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Historique des commandes</title>
    <link rel="stylesheet" href="/Vitoffodji/Style/index.css" type="text/css">
</head>
<body class="historique">
    <div class="EnTete">
        <h1>
            SUPER PROMO RENTRÉ 2024: RÉDUCTION SUR VOS MONTRES ET CASQUE PRÉFÉRÉS<br>
            LIVRAISON OFFERTE EN FRANCE 🇫🇷 ET EU🇪🇺                
        </h1>
    </div>

    <h2>Historique des commandes</h2>

    <table>
        <tr>
            <th>ID Commande</th>
            <th>ID Article</th>
            <th>Nom de l'article</th>
            <th>Prix</th>
            <th>Quantité commandée</th>
            <th>État de la commande</th>
        </tr>
        <?php
        foreach ($historique as $commande) {
            echo '<tr>';
            echo '<td>' . $commande['id_commande'] . '</td>';
            echo '<td>' . $commande['id_art'] . '</td>';
            echo '<td>' . $commande['nom'] . '</td>';
            echo '<td>' . $commande['prix'] . ' €</td>';
            echo '<td>' . $commande['quantite'] . '</td>';
            echo '<td>' . ($commande['envoi'] ? 'Envoyée' : 'En attente') . '</td>';
            echo '</tr>';
        }
        ?>
    </table>
    
    <p><a href="../index.php">Retour</a></p>
</body>
</html>
