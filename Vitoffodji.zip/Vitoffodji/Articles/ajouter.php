<?php
session_start();

// Vérifiez si la variable de session "panier" existe
if (isset($_SESSION['panier'])) {
    $panier = $_SESSION['panier'];

    // Récupérez les données du formulaire (id_article et quantite)
    $id_article = $_POST['id_article'];
    $quantite = $_POST['quantite'];

    // Vérifiez si l'article est déjà dans le panier
    $article_existe = false;
    foreach ($panier as &$article) {
        if ($article['id_article'] == $id_article) {
            // L'article est déjà dans le panier, mettez à jour la quantité
            $article['quantite'] += $quantite;
            $article_existe = true;
            break;
        }
    }

    if (!$article_existe) {
        // L'article n'est pas dans le panier, ajoutez-le
        $nouvel_article = ['id_article' => $id_article, 'quantite' => $quantite];
        $panier[] = $nouvel_article;
    }
} else {
    // La variable de session "panier" n'existe pas, créez-la avec l'article
    $panier = [['id_article' => $_POST['id_article'], 'quantite' => $_POST['quantite']]];
}

// Mettez à jour la variable de session "panier"
$_SESSION['panier'] = $panier;

// Redirigez vers la page "index.php"
header("Location: ../index.php");
exit;
?>
