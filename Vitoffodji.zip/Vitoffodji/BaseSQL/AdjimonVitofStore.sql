-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:8889
-- Généré le : ven. 08 déc. 2023 à 19:23
-- Version du serveur : 5.7.39
-- Version de PHP : 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `AdjimonVitofStore`
--

-- --------------------------------------------------------

--
-- Structure de la table `Articles`
--

CREATE TABLE `Articles` (
  `id_art` int(5) NOT NULL,
  `nom` varchar(20) NOT NULL,
  `quantite` int(40) NOT NULL,
  `prix` double NOT NULL,
  `url_photo` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `ID_STRIPE_PRODUIT` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Articles`
--

INSERT INTO `Articles` (`id_art`, `nom`, `quantite`, `prix`, `url_photo`, `description`, `ID_STRIPE_PRODUIT`) VALUES
(1, 'Montre connectée', 10, 800, '/Vitoffodji/Images/capture1.webp', 'La montre connectée M1 ', 'price_1OKph3ELB90luxXqvLUsCwUR'),
(2, 'Casque Ecouteur', 16, 699, '/Vitoffodji/Images/Capture2.webp', 'Casque écouteur Casque stéréo filaire avec micro pour Smartphone. ', 'price_1OKpgCELB90luxXq6dt1Adf8'),
(3, 'telephone', 20, 999, '/Vitoffodji/Images/capture3.webp', 'L\'iPhone15 pros max', 'price_1OKpe3ELB90luxXqokMclAb8');

-- --------------------------------------------------------

--
-- Structure de la table `Clients`
--

CREATE TABLE `Clients` (
  `id_client` int(11) NOT NULL,
  `nom` varchar(50) DEFAULT NULL,
  `prenom` varchar(50) DEFAULT NULL,
  `adresse` text,
  `numero` int(11) DEFAULT NULL,
  `mail` varchar(50) DEFAULT NULL,
  `mdp` varchar(256) DEFAULT NULL,
  `ID_STRIPE` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Clients`
--

INSERT INTO `Clients` (`id_client`, `nom`, `prenom`, `adresse`, `numero`, `mail`, `mdp`, `ID_STRIPE`) VALUES
(62, 'VITOFF', 'AD', '13556 rue du monde ', 989089899, 'jeromevitofAD@gmail.com', '$2y$10$.gIEwGonQimZYjEwc8esu.mIdeGhJ86mvLDwaYikZBqtllJFpWn1K', 'cus_P8ePLhkAp8xhMv'),
(63, 'Durant', 'Pablo', 'AZERTY 123', 1234567, 'pablodurant@gmail.com', '$2y$10$tQL0Iw35Y7kMUnMD04PjHelTI5u8aJCcz3BrdBCpNy8Tlk.qzJWoK', '63');

-- --------------------------------------------------------

--
-- Structure de la table `Commandes`
--

CREATE TABLE `Commandes` (
  `id_commande` int(11) NOT NULL,
  `id_art` int(11) DEFAULT NULL,
  `id_client` int(11) DEFAULT NULL,
  `quantite` int(11) DEFAULT NULL,
  `envoi` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Commandes`
--

INSERT INTO `Commandes` (`id_commande`, `id_art`, `id_client`, `quantite`, `envoi`) VALUES
(23, 2, 62, 4, 0),
(24, 3, 62, 3, 0),
(25, 3, 62, 29, 0),
(26, 1, 63, 1, 0);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `Articles`
--
ALTER TABLE `Articles`
  ADD PRIMARY KEY (`id_art`);

--
-- Index pour la table `Clients`
--
ALTER TABLE `Clients`
  ADD PRIMARY KEY (`id_client`),
  ADD UNIQUE KEY `mail` (`mail`);

--
-- Index pour la table `Commandes`
--
ALTER TABLE `Commandes`
  ADD PRIMARY KEY (`id_commande`),
  ADD KEY `id_art` (`id_art`),
  ADD KEY `id_client` (`id_client`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `Clients`
--
ALTER TABLE `Clients`
  MODIFY `id_client` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT pour la table `Commandes`
--
ALTER TABLE `Commandes`
  MODIFY `id_commande` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `Commandes`
--
ALTER TABLE `Commandes`
  ADD CONSTRAINT `commandes_ibfk_1` FOREIGN KEY (`id_art`) REFERENCES `Articles` (`id_art`),
  ADD CONSTRAINT `commandes_ibfk_2` FOREIGN KEY (`id_client`) REFERENCES `Clients` (`id_client`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
