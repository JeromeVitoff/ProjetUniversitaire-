<!DOCTYPE html>
<html lang="fr">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Votre Titre</title>
    <link rel="stylesheet" href="/Vitoffodji/Style/index.css" type="text/css">
</head>
<body class="accueil">
    <div class="EnTete">
        <h1>
            SUPER PROMO RENTRÉ 2024: RÉDUCTION SUR VOS MONTRES ET CASQUE PRÉFÉRÉS<br>
            LIVRAISON OFFERTE EN FRANCE 🇫🇷 ET EU🇪🇺
        </h1>
    </div>
</body>
</html>



<!--  Inclure l'en-tête sur les pages sans répéter ça avec include("header.php)-->
