<?php
   function getBd(){
        $bdd = new PDO('mysql:host=localhost;dbname=AdjimonVitofStore;charset=utf8', 'root', 'root');
        return $bdd;
    } 
                     
?>    
