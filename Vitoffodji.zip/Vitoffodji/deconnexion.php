<?php
session_start();

// Détruisez la session pour déconnecter l'utilisateur
session_destroy();

// Redirigez l'utilisateur vers la page d'accueil (index.php)
header("Location: index.php");
exit;
?>